package components.oefening01_trafficlights.Model;

public enum TrafficLightColor {
    TL_GREEN, TL_YELLOW, TL_RED;
}
