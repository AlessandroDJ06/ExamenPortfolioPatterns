package components.oefening01_trafficlights.Model;


public enum TrafficLightStatus {
    LIGHT_OFF, LIGHT_ON ;
}
