package components.oefening01_trafficlights.Model;

public enum FlashingStatus {
    FLASHING_ON,FLASHING_OFF
}
