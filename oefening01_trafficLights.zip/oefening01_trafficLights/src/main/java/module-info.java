module components.oefening01_trafficlights {
    requires javafx.controls;
    exports components.oefening01_trafficlights;
}